declare module "*.vue" {
  const value: any;
  export default value;
}