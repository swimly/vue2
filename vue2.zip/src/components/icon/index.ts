import MIcon from './src/icon.vue'

MIcon.install = Vue => {
  Vue.components(MIcon.name, MIcon)
}
export default MIcon