import MSpace from './src/space.vue'

MSpace.install = Vue => {
  Vue.components(MSpace.name, MSpace)
}
export default MSpace