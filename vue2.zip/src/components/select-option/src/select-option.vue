<template>
  <div class="m-select-option">
  </div>
</template>

<script>
export default {
  name: 'm-select-option',
  props: {
  }
}
</script>

<style lang="css" scoped>
@import './select-option.css';
</style>