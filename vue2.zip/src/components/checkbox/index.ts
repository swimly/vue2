import MCheckbox from './src/checkbox.vue'

MCheckbox.install = Vue => {
  Vue.components(MCheckbox.name, MCheckbox)
}
export default MCheckbox