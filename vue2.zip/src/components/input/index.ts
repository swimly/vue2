import MInput from './src/input.vue'

MInput.install = Vue => {
  Vue.components(MInput.name, MInput)
}
export default MInput