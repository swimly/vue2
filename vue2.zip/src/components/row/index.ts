import MRow from './src/row.vue'

MRow.install = Vue => {
  Vue.components(MRow.name, MRow)
}
export default MRow