import MRadioGroup from './src/radio-group.vue'

MRadioGroup.install = Vue => {
  Vue.components(MRadioGroup.name, MRadioGroup)
}
export default MRadioGroup