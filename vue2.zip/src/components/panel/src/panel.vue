<template>
  <div class="m-panel">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'm-panel',
  props: {
  }
}
</script>

<style lang="css" scoped>
@import './panel.css';
</style>