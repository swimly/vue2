import MSelect from './src/select.vue'

MSelect.install = Vue => {
  Vue.components(MSelect.name, MSelect)
}
export default MSelect