<template>
  <div class="m-select">
  </div>
</template>

<script>
export default {
  name: 'm-select',
  props: {
  }
}
</script>

<style lang="css" scoped>
@import './select.css';
</style>