import MCheckboxGroup from './src/checkbox-group.vue'

MCheckboxGroup.install = Vue => {
  Vue.components(MCheckboxGroup.name, MCheckboxGroup)
}
export default MCheckboxGroup