import MTitle from './src/title.vue'

MTitle.install = Vue => {
  Vue.components(MTitle.name, MTitle)
}
export default MTitle