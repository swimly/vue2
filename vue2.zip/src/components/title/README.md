<style>
  .m-title{
    margin-top:16px;
  }
</style>
# Title

<!-- start -->

### 基础

<div class="code">
  <m-title>h1.Longrise Design</m-title>
  <m-title level="h2">h2.Longrise Design</m-title>
  <m-title level="h3">h3.Longrise Design</m-title>
  <m-title level="h4">h4.Longrise Design</m-title>
  <m-title level="h5">h5.Longrise Design</m-title>
  <m-title level="h6">h6.Longrise Design</m-title>
</div>

<!-- end -->

<!-- start -->

### 属性

|属性名称|描述<div style="width:160px;"></div>|可选值<div style="width:100px;"></div>|可选值<div style="width:40px;"></div>|
|:----|:---------|:-----|:----|
|Header|Title|Title|Title|

<!-- end -->

<script>
  var previews = document.querySelectorAll('.code')
  for (var i = 0; i < previews.length; i++) {
    new Vue({
      el: previews[i]
    })
  }
</script>