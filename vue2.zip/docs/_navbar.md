<div class="logo">
  <img src="docs/assets/images/logo.png"/>
  <h1>永兴元前端规范</h1>
  <p>vue</p>
</div>

<div class="tool" id="tool">
  <!-- <a href="#/src/examples/README.md">示例</a>
  <a href="dist/common.css" title="点击下载样式包" download="common.css">[css]</a>
  <a href="dist/common.js" title="点击下载插件包" download="common.js">[js]</a> -->
</div>